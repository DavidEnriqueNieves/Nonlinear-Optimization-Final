function c = sqrt(a)
% SQRT for adiff objects.

c = a.^(0.5);
   
